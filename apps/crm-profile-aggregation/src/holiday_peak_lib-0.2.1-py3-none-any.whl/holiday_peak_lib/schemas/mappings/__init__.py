"""Schema mapping package marker."""
